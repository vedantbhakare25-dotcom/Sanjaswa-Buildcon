import { AnimatePresence, motion } from 'framer-motion';
import { useEffect, useMemo, useState } from 'react';

const heroImageModules = import.meta.glob(
  '../../assets/images/hero/*.{jpg,jpeg,png,webp,avif}',
  { eager: true, import: 'default' },
);

const HERO_IMAGES = Object.values(heroImageModules);
const SLIDE_INTERVAL = 6000;

function BackgroundSlideshow() {
  const [activeIndex, setActiveIndex] = useState(0);
  const hasImages = HERO_IMAGES.length > 0;

  useEffect(() => {
    if (!hasImages) {
      return undefined;
    }

    const slideshowTimer = window.setInterval(() => {
      setActiveIndex((currentIndex) => (currentIndex + 1) % HERO_IMAGES.length);
    }, SLIDE_INTERVAL);

    return () => window.clearInterval(slideshowTimer);
  }, [hasImages]);

  const activeImage = useMemo(
    () => (hasImages ? HERO_IMAGES[activeIndex] : null),
    [activeIndex, hasImages],
  );

  return (
    <div className="absolute inset-0 overflow-hidden bg-black">
      {hasImages ? (
        <AnimatePresence initial={false}>
          <motion.img
            key={activeImage}
            src={activeImage}
            alt=""
            aria-hidden="true"
            className="absolute inset-0 h-full w-full object-cover"
            initial={{ opacity: 0, scale: 1.05 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.02 }}
            transition={{ duration: 2.2, ease: [0.22, 1, 0.36, 1] }}
          />
        </AnimatePresence>
      ) : (
        <div
          className="absolute inset-0 bg-gradient-to-br from-neutral-900 via-neutral-950 to-black"
          aria-hidden="true"
        />
      )}

      <div
        className="absolute inset-0"
        style={{ backgroundColor: 'var(--color-hero-overlay)' }}
      />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,var(--color-hero-vignette)_78%)]" />
      <div className="absolute inset-x-0 top-0 h-48 bg-gradient-to-b from-black/65 to-transparent" />
      <div className="absolute inset-x-0 bottom-0 h-64 bg-gradient-to-t from-black/75 to-transparent" />
    </div>
  );
}

export default BackgroundSlideshow;
