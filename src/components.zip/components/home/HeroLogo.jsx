import { motion } from 'framer-motion';
import logo from '../../assets/images/logo.png';

function HeroLogo() {
  return (
    <motion.img
      src={logo}
      alt="Sanjaswa Builcon logo"
      className="mx-auto h-36 w-36 object-contain brightness-0 invert drop-shadow-[0_4px_24px_var(--color-hero-shadow)] sm:h-48 sm:w-48 md:h-56 md:w-56"
      initial={{ opacity: 0, y: 50, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 1.3, ease: [0.22, 1, 0.36, 1] }}
    />
  );
}

export default HeroLogo;
