import { motion } from "framer-motion";

function ScrollIndicator() {
  return (
    <motion.div
      className="absolute bottom-12 left-1/2 z-20 flex -translate-x-1/2 flex-col items-center gap-4 pointer-events-none sm:bottom-14 md:bottom-[3.75rem]"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1.4, delay: 2.2, ease: [0.22, 1, 0.36, 1] }}
      aria-hidden="true"
    >
      <span className="font-sans text-[0.5625rem] font-extralight uppercase tracking-[0.38em] text-white/65 sm:text-[0.625rem]">
        Scroll To Know More
      </span>

      <motion.div
        className="flex flex-col items-center"
        animate={{ y: [0, 5, 0], opacity: [0.55, 0.95, 0.55] }}
        transition={{
          duration: 3.6,
          repeat: Infinity,
          ease: [0.45, 0, 0.55, 1],
        }}
      >
        <span className="mb-2 block h-8 w-px bg-gradient-to-b from-white/0 via-white/45 to-white/20" />
        <svg
          width="16"
          height="9"
          viewBox="0 0 16 9"
          fill="none"
          className="text-white/75"
        >
          <path
            d="M1.5 1.25L8 7.25L14.5 1.25"
            stroke="currentColor"
            strokeWidth="0.75"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </motion.div>
    </motion.div>
  );
}

export default ScrollIndicator;
