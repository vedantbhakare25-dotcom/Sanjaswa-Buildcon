import { motion } from "framer-motion";

function HeroCTA() {
  return (
    <motion.button
      type="button"
      className="group relative inline-flex min-h-[3.5rem] items-center justify-center border border-white/40 bg-transparent px-12 py-3.5 font-sans text-[0.6875rem] font-light uppercase tracking-[0.34em] text-[var(--color-hero-text)] transition-all duration-700 ease-out hover:border-white/75 hover:bg-white/[0.06] hover:tracking-[0.36em] focus:outline-none focus-visible:ring-1 focus-visible:ring-white/40 focus-visible:ring-offset-4 focus-visible:ring-offset-transparent sm:min-h-[3.75rem] sm:px-14 sm:text-xs sm:tracking-[0.36em]"
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 1, delay: 1.6, ease: [0.22, 1, 0.36, 1] }}
    >
      Enquire More
    </motion.button>
  );
}

export default HeroCTA;
