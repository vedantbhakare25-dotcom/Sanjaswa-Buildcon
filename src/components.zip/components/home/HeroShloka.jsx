import { motion } from "framer-motion";

function HeroShloka() {
  return (
    <motion.p
      className="font-sanskrit text-lg font-normal leading-[1.7] tracking-[0.04em] text-[var(--color-hero-text-muted)] [text-shadow:0_1px_20px_var(--color-hero-shadow)] sm:text-xl md:text-2xl md:leading-[1.75]"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 1, delay: 1.05, ease: [0.22, 1, 0.36, 1] }}
    >
      योगः कर्मसु कौशलम्।
    </motion.p>
  );
}

export default HeroShloka;
