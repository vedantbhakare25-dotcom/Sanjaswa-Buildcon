import logo from "../../assets/images/logo.png";
import BackgroundSlideshow from "./BackgroundSlideshow.jsx";
import HeroContent from "./HeroContent.jsx";
import MobileMenuButton from "./MobileMenuButton.jsx";
import ScrollIndicator from "./ScrollIndicator.jsx";

function HeroSection() {
  return (
    <section className="relative flex h-screen min-h-[640px] overflow-hidden bg-black text-[var(--color-hero-text)]">
      <BackgroundSlideshow />

      <header className="pointer-events-none fixed inset-x-0 top-0 z-30">
        <img
          src={logo}
          alt="Sanjaswa Builcon"
          className="pointer-events-auto fixed left-6 top-6 h-11 w-11 object-contain brightness-0 invert drop-shadow-[0_2px_12px_var(--color-hero-shadow)] sm:left-10 sm:top-10 sm:h-[3.25rem] sm:w-[3.25rem]"
        />
        <div className="pointer-events-auto">
          <MobileMenuButton />
        </div>
      </header>

      <div className="relative z-10 flex h-full w-full items-start justify-center px-6 pb-32 pt-[12vh] sm:pb-36 sm:pt-[14vh] md:pt-[16vh] lg:pt-[17vh]">
        <HeroContent />
      </div>

      <ScrollIndicator />
    </section>
  );
}

export default HeroSection;
