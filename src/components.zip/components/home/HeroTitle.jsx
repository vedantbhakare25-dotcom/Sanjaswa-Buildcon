import { motion } from "framer-motion";

function HeroTitle() {
  return (
    <motion.h1
      className="font-display text-[1.875rem] font-medium uppercase leading-[1.15] tracking-[0.24em] text-[var(--color-hero-text)] [text-shadow:0_2px_28px_var(--color-hero-shadow)] sm:text-[2.75rem] sm:tracking-[0.28em] md:text-5xl md:tracking-[0.3em] lg:text-[3.5rem] lg:tracking-[0.32em]"
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 1.1, delay: 0.55, ease: [0.22, 1, 0.36, 1] }}
    >
      Sanjaswa Builcon
    </motion.h1>
  );
}

export default HeroTitle;
