import HeroCTA from "./HeroCTA.jsx";
import HeroLogo from "./HeroLogo.jsx";
import HeroShloka from "./HeroShloka.jsx";
import HeroTitle from "./HeroTitle.jsx";

function HeroContent() {
  return (
    <div className="mx-auto flex w-full max-w-4xl flex-col items-center text-center">
      <HeroLogo />

      <div className="mt-12 space-y-8 sm:mt-14 sm:space-y-9 md:mt-16 md:space-y-10">
        <HeroTitle />
        <HeroShloka />
      </div>

      <div className="mt-16 sm:mt-20 md:mt-24">
        <HeroCTA />
      </div>
    </div>
  );
}

export default HeroContent;
