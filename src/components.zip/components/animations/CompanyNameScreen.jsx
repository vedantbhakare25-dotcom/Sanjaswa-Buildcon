import { motion } from 'framer-motion';

const screenMotion = {
  initial: { opacity: 0, y: 30, filter: 'blur(8px)' },
  animate: {
    opacity: 1,
    y: 0,
    filter: 'blur(0px)',
    transition: { duration: 1.4, ease: [0.22, 1, 0.36, 1] },
  },
  exit: {
    opacity: 0,
    y: -16,
    filter: 'blur(8px)',
    transition: { duration: 0.9, ease: [0.55, 0.06, 0.68, 0.19] },
  },
};

function CompanyNameScreen() {
  return (
    <motion.section
      className="relative z-10 flex min-h-screen items-center justify-center px-6"
      variants={screenMotion}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      <div className="text-center">
        <p className="mb-5 font-sans text-xs font-semibold uppercase text-brand-primary">
          Building With Precision
        </p>
        <h1 className="font-display text-4xl font-semibold uppercase text-brand-dark drop-shadow-[0_18px_48px_var(--color-intro-shadow)] sm:text-6xl md:text-7xl">
          SANJASWA BUILCON
        </h1>
      </div>
    </motion.section>
  );
}

export default CompanyNameScreen;
