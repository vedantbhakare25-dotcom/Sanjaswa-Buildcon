import { AnimatePresence } from 'framer-motion';
import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import CompanyNameScreen from './CompanyNameScreen.jsx';
import LogoScreen from './LogoScreen.jsx';
import ShlokaScreen from './ShlokaScreen.jsx';

const INTRO_TIMELINE = [
  {
    id: 'logo',
    duration: 3200,
    component: LogoScreen,
  },
  {
    id: 'company-name',
    duration: 3600,
    component: CompanyNameScreen,
  },
  {
    id: 'shloka',
    duration: 4200,
    component: ShlokaScreen,
  },
];

function IntroSequence() {
  const navigate = useNavigate();
  const [stageIndex, setStageIndex] = useState(0);

  const currentStage = INTRO_TIMELINE[stageIndex];
  const ActiveScreen = currentStage?.component;

  const totalStages = useMemo(() => INTRO_TIMELINE.length, []);

  useEffect(() => {
    if (!currentStage) {
      navigate('/home', { replace: true });
      return undefined;
    }

    const stageTimer = window.setTimeout(() => {
      setStageIndex((currentIndex) => currentIndex + 1);
    }, currentStage.duration);

    return () => window.clearTimeout(stageTimer);
  }, [currentStage, navigate]);

  return (
    <main className="relative min-h-screen overflow-hidden bg-[radial-gradient(circle_at_center,var(--color-brand-light)_0%,var(--color-brand-secondary)_58%,color-mix(in_srgb,var(--color-brand-primary)_34%,var(--color-brand-secondary))_100%)] text-brand-dark">
      <div className="absolute inset-0 bg-[linear-gradient(135deg,color-mix(in_srgb,var(--color-brand-light)_78%,transparent),color-mix(in_srgb,var(--color-brand-primary)_10%,transparent))]" />
      <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-brand-light/70 to-transparent" />
      <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-brand-dark/12 to-transparent" />

      <AnimatePresence mode="wait">
        {ActiveScreen ? (
          <ActiveScreen key={currentStage.id} totalStages={totalStages} />
        ) : null}
      </AnimatePresence>
    </main>
  );
}

export default IntroSequence;
