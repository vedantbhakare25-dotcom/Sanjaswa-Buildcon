import { motion } from 'framer-motion';
import logo from '../../assets/images/logo.png';

const screenMotion = {
  initial: { opacity: 0, scale: 0.92, filter: 'blur(10px)' },
  animate: {
    opacity: 1,
    scale: 1,
    filter: 'blur(0px)',
    transition: { duration: 1.35, ease: [0.22, 1, 0.36, 1] },
  },
  exit: {
    opacity: 0,
    scale: 0.98,
    filter: 'blur(10px)',
    transition: { duration: 1.15, ease: [0.55, 0.06, 0.68, 0.19] },
  },
};

function LogoScreen() {
  return (
    <motion.section
      className="relative z-10 flex min-h-screen items-center justify-center px-6"
      variants={screenMotion}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      <motion.img
        src={logo}
        alt="Sanjaswa Builcon logo"
        className="h-60 w-60 object-contain sm:h-72 sm:w-72 md:h-80 md:w-80"
        animate={{ y: [0, -10, 0], scale: [1, 1.035, 1] }}
        transition={{ duration: 4.4, repeat: Infinity, ease: 'easeInOut' }}
      />
    </motion.section>
  );
}

export default LogoScreen;
