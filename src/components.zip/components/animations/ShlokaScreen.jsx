import { motion } from 'framer-motion';

const screenMotion = {
  initial: { opacity: 0, y: 28, filter: 'blur(8px)' },
  animate: {
    opacity: 1,
    y: 0,
    filter: 'blur(0px)',
    transition: { duration: 1.0, ease: [0.22, 1, 0.36, 1] },
  },
  exit: {
    opacity: 0,
    y: -18,
    filter: 'blur(8px)',
    transition: { duration: 0.8, ease: [0.55, 0.06, 0.68, 0.19] },
  },
};

function ShlokaScreen() {
  return (
    <motion.section
      className="relative z-10 flex min-h-screen items-center justify-center px-6"
      variants={screenMotion}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      <div className="text-center">
        <motion.p
          className="font-sanskrit text-5xl font-semibold leading-tight text-brand-dark sm:text-6xl md:text-7xl"
          animate={{ y: [0, -6, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
        >
          दृढमूलं हि यत् कार्यं न तद् विपद्यते क्वचित्।
        </motion.p>
        <p className="mt-7 font-display text-sm uppercase text-[var(--color-intro-muted)] sm:text-base">
          A work built on a strong foundation never fails.
        </p>
      </div>
    </motion.section>
  );
}

export default ShlokaScreen;
