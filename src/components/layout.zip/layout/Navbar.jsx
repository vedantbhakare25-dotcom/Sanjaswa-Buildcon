import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Menu } from "lucide-react";

import logo from "../../assets/images/logo.png";

export default function Navbar({ onMenuClick }) {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    window.addEventListener("scroll", handleScroll);

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <motion.header
      animate={{
        backgroundColor: scrolled ? "rgba(15,15,15,.55)" : "rgba(0,0,0,0)",

        backdropFilter: scrolled ? "blur(18px)" : "blur(0px)",

        borderBottomColor: scrolled
          ? "rgba(255,255,255,.08)"
          : "rgba(255,255,255,.03)",
      }}
      transition={{
        duration: 0.4,
      }}
      className="
        fixed
        top-0
        left-0
        right-0
        z-50
        border-b
      "
    >
      <div className="max-w-[1800px] mx-auto">
        <div className="h-24 flex items-center justify-between px-8 md:px-14 xl:px-20">
          {/* Logo */}

          <motion.img
            whileHover={{
              opacity: 0.8,
            }}
            transition={{
              duration: 0.3,
            }}
            src={logo}
            alt="Sanjaswa"
            className="
              h-12
              w-auto
              cursor-pointer
              select-none
            "
          />

          {/* Menu */}

          <motion.button
            whileHover={{
              opacity: 0.75,
            }}
            whileTap={{
              scale: 0.95,
            }}
            onClick={onMenuClick}
            className="
              flex
              items-center
              gap-3
              uppercase
              tracking-[.35em]
              text-[12px]
              text-white
            "
          >
            <span>MENU</span>

            <Menu size={20} strokeWidth={1.8} />
          </motion.button>
        </div>
      </div>
    </motion.header>
  );
}
